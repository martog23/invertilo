import express from 'express';
import db from './db.js';
import passport from 'passport';
import Authentication from "./auth.js"
import path from 'path';
import fs from 'fs';

const dirname = fs.realpathSync('.');

class DictionaryBackendServer {
  constructor() {
    const app = express();
    app.use(express.json());
    app.use(express.static('public'));
    app.use(express.urlencoded({ extended: false }));
    const authentication = new Authentication(app);

    app.get('/lookup/:word', authentication.checkAuthenticated, this.doLookup);
    app.post('/save/', authentication.checkAuthenticated, this.doSave);
    app.delete('/delete/', authentication.checkAuthenticated, this.doDelete);

    app.get('/login/', this.login);
    app.get('/', authentication.checkAuthenticated, this.goHome);

    // aca empiezan las diferencias con autenticacion local
    app.get('/auth/google/', passport.authenticate('google', {
       scope: ['email', 'profile']
      }));

    app.get('/auth/google/callback', passport.authenticate('google', {
      successRedirect: '/',
      failureRedirect: '/login'
    }));

    app.post("/logout", (req,res) => {
     req.logOut(err=>console.log(err));
     res.redirect("/login");
   })
   
    // Start server
    app.listen(3000, () => console.log('Listening on port 3000'));
  }

  async login(req, res) {
    res.sendFile(path.join(dirname, "public/login.html"));
  }

  async goHome(req, res) {
    res.sendFile(path.join( dirname, "public/home.html"));
  }

  async doLookup(req, res) {
    const routeParams = req.params;
    const word = routeParams.word;
    const query = { word: word.toLowerCase() };
    const collection = db.collection("dict");
    const stored = await collection.findOne(query);
    const response = {
      word: word,
      definition: stored ? stored.definition : ''
    };
    res.json(response);
  }

  async doSave(req, res) {
    const query = { word: req.body.word.toLowerCase() };
    const update = { $set: { definition: req.body.definition } };
    const params = { upsert: true };
    const collection = db.collection("dict");
    await collection.updateOne(query, update, params);
    res.json({ success: true });
  }

  async doDelete(req, res) {
    const word = req.body.word.toLowerCase();
    const query = { word: word };
    const collection = db.collection("dict");
    const deleted = await collection.findOneAndDelete(query);
    res.json(deleted.value);
  }
}

new DictionaryBackendServer();