document.addEventListener('DOMContentLoaded', () => { // Ejecuta la función cuando el DOM está completamente cargado
    const menuToggle = document.querySelector('.menu-toggle'); // Selecciona el elemento con la clase 'menu-toggle'
    const submenu = document.querySelector('.submenu'); // Selecciona el elemento con la clase 'submenu'
  
    menuToggle.addEventListener('click', (event) => { // Añade un evento 'click' al elemento 'menu-toggle'
      event.preventDefault(); // Previene el comportamiento predeterminado del evento
      submenu.classList.toggle('menu-open'); // Alterna la clase 'menu-open' en el elemento 'submenu'
    });
});

// Definición de la clase PlazoFijoAPI
class PlazoFijoAPI {
    constructor() {
        this.apiUrl = 'https://api.argentinadatos.com/v1/finanzas/tasas/plazoFijo/'; // URL de la API
        this.entidades = [ // Lista de entidades bancarias
            "BANCO MASVENTAS S.A.",
            "BANCO BBVA ARGENTINA S.A.",
            "BANCO SANTANDER ARGENTINA S.A.",
            "BANCO DE LA CIUDAD DE BUENOS AIRES",
            "BANCO CMF S.A."
        ];
        this.entidadesData = []; // Inicializa los datos de las entidades como un array vacío

        this.fetchEntidadesData(); // Llama al método para obtener los datos de las entidades
        this.setupEventListeners(); // Configura los listeners de eventos
    }

    async fetchEntidadesData() {
        try {
            const response = await fetch(this.apiUrl); // Realiza una petición a la API
            const data = await response.json(); // Convierte la respuesta a JSON

            this.entidadesData = data.filter((item) => { // Filtra los datos según las entidades deseadas
                return this.entidades.includes(item.entidad);
            });

            this.renderEntidades(); // Muestra las entidades en el DOM
        } catch (error) {
            console.error('Error al obtener datos de la API:', error); // Maneja errores en la petición
        }
    }

    setupEventListeners() {
        const descButton = document.getElementById('desc'); // Selecciona el botón de orden descendente por su id
        const ascButton = document.getElementById('asc'); // Selecciona el botón de orden ascendente por su id

        descButton.addEventListener('click', () => { // Añade un evento 'click' al botón de orden descendente
            this.sortEntidades('desc');
        });

        ascButton.addEventListener('click', () => { // Añade un evento 'click' al botón de orden ascendente
            this.sortEntidades('asc');
        });
    }

    sortEntidades(order) {
        if (order === 'desc') {
            this.entidadesData.sort((a, b) => b.tnaClientes - a.tnaClientes); // Ordena las entidades de mayor a menor tasa
        } else if (order === 'asc') {
            this.entidadesData.sort((a, b) => a.tnaClientes - b.tnaClientes); // Ordena las entidades de menor a mayor tasa
        }

        this.renderEntidades(); // Muestra las entidades ordenadas en el DOM
    }

    renderEntidades() {
        const entidadesContainer = document.getElementById('entidades-container'); // Selecciona el contenedor de las entidades por su id
        entidadesContainer.innerHTML = ''; // Limpia el contenido actual del contenedor

        this.entidadesData.forEach((item) => { // Recorre los datos de las entidades y crea elementos para cada una
            const entidadElement = document.createElement('div');
            entidadElement.classList.add('entidad');

            entidadElement.innerHTML = ` 
                <div>
                    <h2>${item.entidad}</h2>
                    <p>Tasa de Plazo Fijo (TNA Clientes): ${item.tnaClientes}%</p>
                </div>
                <img src="${item.logo}" alt="${item.entidad} Logo">
            `;

            entidadesContainer.appendChild(entidadElement); // Añade el elemento de la entidad al contenedor
        });
    }
}

const plazoFijoAPI = new PlazoFijoAPI(); // Crea una nueva instancia de PlazoFijoAPI

// Definición de la clase CryptoAPI
class CryptoAPI {
    constructor() {
        this.apiUrl = 'https://raw.githubusercontent.com/martog23/invertilo/main/cripto.json'; // URL de la API
        this.cryptosData = []; // Inicializa los datos de las criptomonedas como un array vacío

        this.fetchCryptosData(); // Llama al método para obtener los datos de las criptomonedas
        this.setupEventListeners(); // Configura los listeners de eventos
    }

    async fetchCryptosData() {
        try {
            const response = await fetch(this.apiUrl); // Realiza una petición a la API
            const data = await response.json(); // Convierte la respuesta a JSON

            this.cryptosData = data.criptos; // Asigna los datos de las criptomonedas

            this.renderCryptos(); // Muestra las criptomonedas en el DOM
        } catch (error) {
            console.error('Error al obtener datos de la API de criptomonedas:', error); // Maneja errores en la petición
        }
    }

    setupEventListeners() {
        const descButton = document.getElementById('crypto-desc'); // Selecciona el botón de orden descendente por su id
        const ascButton = document.getElementById('crypto-asc'); // Selecciona el botón de orden ascendente por su id

        descButton.addEventListener('click', () => { // Añade un evento 'click' al botón de orden descendente
            this.sortCryptos('desc');
        });

        ascButton.addEventListener('click', () => { // Añade un evento 'click' al botón de orden ascendente
            this.sortCryptos('asc');
        });
    }

    sortCryptos(order) {
        if (order === 'desc') {
            this.cryptosData.sort((a, b) => b.precio - a.precio); // Ordena las criptomonedas de mayor a menor precio
        } else if (order === 'asc') {
            this.cryptosData.sort((a, b) => a.precio - b.precio); // Ordena las criptomonedas de menor a mayor precio
        }

        this.renderCryptos(); // Muestra las criptomonedas ordenadas en el DOM
    }

    renderCryptos() {
        const cryptoContainer = document.getElementById('crypto-container'); // Selecciona el contenedor de las criptomonedas por su id
        cryptoContainer.innerHTML = ''; // Limpia el contenido actual del contenedor

        this.cryptosData.forEach((item) => { // Recorre los datos de las criptomonedas y crea elementos para cada una
            const cryptoElement = document.createElement('div');
            cryptoElement.classList.add('crypto');

            cryptoElement.innerHTML = ` 
                <div>
                    <h2>${item.crypto}</h2>
                    <p>Precio: ${item.precio} USD</p>
                </div>
                <img src="${item.foto}" alt="${item.crypto} Logo">
            `;

            cryptoContainer.appendChild(cryptoElement); // Añade el elemento de la criptomoneda al contenedor
        });
    }
}

const cryptoAPI = new CryptoAPI(); // Crea una nueva instancia de CryptoAPI

// Definición de la clase FondoComunAPI
class FondoComunAPI {
    constructor() {
        this.apiUrl = 'https://raw.githubusercontent.com/martog23/invertilo/main/tna.json'; // URL de la API
        this.fondoComunData = []; // Inicializa los datos del fondo común como un array vacío

        this.fetchFondoComunData(); // Llama al método para obtener los datos del fondo común
        this.setupEventListeners(); // Configura los listeners de eventos
    }

    async fetchFondoComunData() {
        try {
            const response = await fetch(this.apiUrl); // Realiza una petición a la API
            const data = await response.json(); // Convierte la respuesta a JSON

            this.fondoComunData = data.tna; // Asigna los datos del fondo común

            this.renderFondoComun(); // Muestra los fondos comunes en el DOM
        } catch (error) {
            console.error('Error al obtener datos de la API de Fondo Común:', error); // Maneja errores en la petición
        }
    }

    setupEventListeners() {
        const fondoAscButton = document.getElementById('fondo-asc'); // Selecciona el botón de orden ascendente por su id
        const fondoDescButton = document.getElementById('fondo-desc'); // Selecciona el botón de orden descendente por su id

        fondoAscButton.addEventListener('click', () => { // Añade un evento 'click' al botón de orden ascendente
            this.sortFondoComun('asc');
        });

        fondoDescButton.addEventListener('click', () => { // Añade un evento 'click' al botón de orden descendente
            this.sortFondoComun('desc');
        });
    }

    sortFondoComun(order) {
        if (order === 'desc') {
            this.fondoComunData.sort((a, b) => parseFloat(b.tna) - parseFloat(a.tna)); // Ordena los fondos comunes de mayor a menor tasa
        } else if (order === 'asc') {
            this.fondoComunData.sort((a, b) => parseFloat(a.tna) - parseFloat(b.tna)); // Ordena los fondos comunes de menor a mayor tasa
        }

        this.renderFondoComun(); // Muestra los fondos comunes ordenados en el DOM
    }

    renderFondoComun() {
        const fondoContainer = document.getElementById('fondo-container'); // Selecciona el contenedor de los fondos comunes por su id
        fondoContainer.innerHTML = ''; // Limpia el contenido actual del contenedor
    
        this.fondoComunData.forEach((fondo) => { // Recorre los datos de los fondos comunes y crea elementos para cada uno
            const fondoElement = document.createElement('div');
            fondoElement.classList.add('fondo');
    
            fondoElement.innerHTML = ` 
                <div>
                    <h2>${fondo.banco}</h2>
                    <p>TNA: ${fondo.tna}</p>
                </div>
                <img src="${fondo.foto}" alt="${fondo.banco} Logo">
            `;
    
            fondoContainer.appendChild(fondoElement); // Añade el elemento del fondo común al contenedor
        });
    }
}

const fondoComunAPI = new FondoComunAPI(); // Crea una nueva instancia de FondoComunAPI

